Add global scripts here!

Scripts in this folder (.lua, .hx) will run everywhere - on all songs and states.

For state-specific scripts, use the "states/" subfolder.
For global advanced scripts with classes, use the "global/" subfolder.
For song-specific scripts, put them in "songs/[song-name]/script.lua" or "script.hx".