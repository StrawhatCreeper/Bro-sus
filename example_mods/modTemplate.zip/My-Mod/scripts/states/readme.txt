Add state-specific scripts here!

Create a folder for each state (e.g., "MainMenuState", "PlayState", "StoryMenuState").
Scripts inside each state folder will run only when that state is active.

Supported formats: .lua, .hx, .hscript, .hsc, .hxs
Variables like "this", "game", "FlxG" are pre-injected.

Example structure:
  states/MainMenuState/myScript.hx
  states/PlayState/advanced/CustomClass.hx
